## Copyright (C) 2019 giann
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} sgn (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: giann <giann@LAPTOP-0ION2SU9>
## Created: 2019-03-14

function y = sgn(x)
%SGN   Modified signum function.
%   For each element of X, SIGN(X) returns 1 if the element
%   is greater than or equal to zero, and -1 if it is
%   less than zero.
%
%   See also SIGN.
%
%   Author: Nabin Sharma
%   Date: 2009/03/15
y = (x>=0) + (-1)*(x<0);
end
