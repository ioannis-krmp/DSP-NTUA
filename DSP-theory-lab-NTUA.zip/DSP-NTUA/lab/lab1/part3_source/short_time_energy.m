## Copyright (C) 2019 giann
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} short_time_energy (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: giann <giann@LAPTOP-0ION2SU9>
## Created: 2019-03-14

function En = short_time_energy(x,wintype,winamp,winlen)
%ENERGY   Short-time energy computation.
%   y = ENERGY(X,WINTYPE,WINAMP,WINLEN) computes the short-time enery of
%   the sequence X. 
%
%   WINTYPE defines the window type. RECTWIN, HAMMING, HANNING, and
%   BLACKAMN are the possible choices. WINAMP sets the amplitude of the
%   window and the length of the window is WINLEN. 
%   
%   See also RECTWIN, HAMMING, HANNING, BARTLETT, BLACKMAN.
%
%   Author: Nabin Sharma
%   Date: 2009/03/15
error(nargchk(1,4,nargin,'struct'));
% generate the window
win = (winamp*(window(str2func(wintype),winlen))).';
% enery calculation
x2 = x.^2;
En = winconv(x2,wintype,win,winlen);
end
