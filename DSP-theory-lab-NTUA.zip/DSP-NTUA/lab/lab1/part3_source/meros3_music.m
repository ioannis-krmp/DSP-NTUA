%Anaparastash tou shmatos grafika ston xrono
filename='music.wav';
[kataggelia,fs]=audioread(filename);
figure;
plot(kataggelia)
title('speech utterance signal')
xlabel('samples')
ylabel('signal')

%C.1
[x,Fs] = audioread('music.wav'); % word is: so
x = x.';
N = length(x); % signal length
n = 0:N-1;
ts = n*(1/Fs); % time for signal
% define the window
for(i=8:12) %efarmozw vhma 40 gia to metakinoumeno parathiro kai diasthma[320,480]
wintype = 'hamming';
winlen = i*40; %
winamp = [0.5,1];%*(1/winlen); %ylim(); [0.5,1]*(1/winlen);
% find the zero-crossing rate
zc = zerocross(x,wintype,winamp(1),winlen);
% find the zero-crossing rate
E = short_time_energy(x,wintype,winamp(2),winlen);
% time index for the ST-ZCR and STE after delay compensation
out = (winlen-1)/2:(N+winlen-1)-(winlen-1)/2;
t = (out-(winlen-1)/2)*(1/Fs);
figure;
plot(ts,x);
hold on;
plot(t,zc(out),'r','Linewidth',2); 
xlabel('t, seconds');
title('Short-time Zero Crossing Rate');
legend('signal','STZCR');
figure;
plot(ts,x);
 hold on;
plot(t,E(out),'r','Linewidth',2);
xlabel('t, seconds');
title('Short-time energy');
legend('signal','STE');
end

