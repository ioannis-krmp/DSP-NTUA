## Copyright (C) 2019 giann
## 
## This program is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
## 
## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
## 
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see
## <https://www.gnu.org/licenses/>.

## -*- texinfo -*- 
## @deftypefn {} {@var{retval} =} winconv (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: giann <giann@LAPTOP-0ION2SU9>
## Created: 2019-03-14

function y = winconv(x,varargin)
%WINCONV   Discrere time convolution of a sequence with a window.
%   y = WINCONV(X) convolves the sequence X with a rectangular window. The
%   length of the window is same as that of X.
%
%   y = WINCONV(X,WINTYPE) convolves the sequence X with the window
%   specified by WINTYPE. WINTYPE can be either 'rect', or 'hamming', or
%   'hanning', or 'bartlett', or 'blackman'. The length of the window is 
%   same as that of X.
%
%   y = WINCONV(X,WINTYPE,WINAMP) convolves the sequence X with the window
%   specified by WINTYPE. The amplitude of the window is set by WINAMP. So
%   WINAMP must be a real number/vector. The length of the window is same 
%   as that of X. WINAMP could be a real constant or a vector with WINLEN 
%   elements.
%   
%   y = WINCONV(X,WINTYPE,WINAMP,WINLEN) convolves the sequence X with the
%   window specified by WINTYPE having amplitude WINAMP and length WINLEN.
%
%   See also CONV, FFT, RECTWIN, HAMMING, HANNING, BARTLETT, BLACKMAN.
%
%   Author: Nabin Sharma
%   Date: 2009/03/15
error(nargchk(1,4,nargin,'struct'));
len = length(varargin);
switch len
    case 0
        wintype = 'hamming'; %rectwin
        A = 1;
        L = length(x);
    case 1
        if ischar(varargin{1})
            wintype = lower(varargin{1});
            A = 1;
            L = length(x);
        end
    case 2
        if ischar(varargin{1}) && isreal(varargin{2})
            wintype = lower(varargin{1});
            A = varargin{2};
            L = length(x);
        end
    case 3
        if ischar(varargin{1}) && isreal(varargin{2}) &&...
                isreal(varargin{3})
            wintype = lower(varargin{1});
            A = varargin{2};
            L = varargin{3};
        end
end
% generate the window
w1 = (window(str2func(wintype),L)).'; A = A(:).';
w = A.*w1;
% perform the convolution using FFT
NFFT = 2^(nextpow2(length(x)+L));
X = fft(x,NFFT); W = fft(w,NFFT);
Y = X.*W;
y = ifft(Y,NFFT);

endfunction
