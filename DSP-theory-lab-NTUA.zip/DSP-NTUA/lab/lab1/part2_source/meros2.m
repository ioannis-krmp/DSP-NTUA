
%MEROS 2//2.1.a
t=linspace(0,2,2000); %epeidh fs=1000Hz
x1=2*cos(2*pi*70*t) + 3*sin(2*pi*140*t) + 0.15*randn(size(t));
%h function randn gia white noise gaussian
figure;
plot(x1);
title('signal 2.1.a')
xlabel('n')
ylabel('x[n]')

%2.1.b
stft_x=specgram(x1,40,20); 
[s,suxnothtes1,xronos1]=specgram(x1,1000,1000,40,20);
figure;
surf(xronos1,suxnothtes1,abs(s)); %surf(____,'edgecolor','none')
xlabel('time');
ylabel('frequencies');
zlabel('|STFT(t,f)| of signal');
view(0,90);

%2.1.c
% [scales,freq]=wavescales('morl',Fs)
%c=cwtft({x,1/fs}.'scales',scales,'wavelet','morl')
%cwtstruct.cfs
[scales,freq]=wavescales('morl',1000);
c=cwtft({x1,1/1000},'scales',scales,'wavelet','morl'); %cwtstruct
figure;
surf(t,freq,abs(c.cfs),'edgecolor','none');
xlabel('time')
ylabel('frequencies')
zlabel('|WT| of signal')
view(0,90);

%2.2.a
x2=1.7*cos(2*pi*90*t) +0.15*randn(size(t));
%gia thn dhmiourgia ths Dirac xrhsimopoiow pinaka 2000 thesewn me 
%mhdenika ektos apo ta shmeia pou dra h Dirac
dirac=[zeros(1,624),5,zeros(1,174),5,zeros(1,1200)];
x3=x2 + dirac;
figure;
plot(x3)
title('2.2.b')
xlabel('samples')
ylabel('signal')

%2.2.b
%stft_x3=specgram(x3,40,20);
[s,suxnothtes2,xronos2]=specgram(x3,1000,1000,40,20);
figure;
contour(xronos2,suxnothtes2,abs(s));
title('2.2.b')
xlabel('time')
ylabel('frequencies')
zlabel('|STFT of x3|')
view(0,90);

%2.2.c
[scales2,freq2]=wavescales('morl',1000);
c=cwtft({x3,1/1000},'scales',scales2,'wavelet','morl'); %cwtstruct
figure;
contour(t,freq2,abs(c.cfs));
title('2.2.c')
xlabel('time')
ylabel('frequencies')
zlabel('|WT| of signal')
view(0,90);
