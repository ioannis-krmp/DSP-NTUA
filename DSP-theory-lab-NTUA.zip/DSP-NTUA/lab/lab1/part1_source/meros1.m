%A.1
n=1:1000;
d(10,:)=sin(0.7217*n)+sin(1.0247*n); %tone 10 because matlab accepts integers greater than 0 
d(1,:)=sin(0.5346*n)+sin(0.9273*n);
d(2,:)=sin(0.5346*n)+sin(1.0247*n);
d(3,:)=sin(0.5346*n)+sin(1.1328*n);
d(4,:)=sin(0.5906*n)+sin(0.9273*n);
d(5,:)=sin(0.5906*n)+sin(1.0247*n);
d(6,:)=sin(0.5906*n)+sin(1.1328*n);
d(7,:)=sin(0.6535*n)+sin(0.9273*n);
d(8,:)=sin(0.6535*n)+sin(1.0247*n);
d(9,:)=sin(0.6535*n)+sin(1.1328*n);
for(i=1:10)
figure;
plot(d(i,:));
title((mod(i,10)));
xlabel(' n samples')
ylabel('signal')
end
%for(i=1:10)
%sound(d(i,:),8000,8);
%end

%A.2
DFTd4=fft(d(4,:));
DFTd6=fft(d(6,:));
%Epeidh sumvainei mirroring gia na to apofygoume pairnoume ta misa deigmata
for(i=1:501)
DFTd4_half(i)=DFTd4(i);
DFTd6_half(i)=DFTd6(i);
end
%DFT is a periodic signal with period=T=2pi,thus,its ok to study one period
%adjast properly x-axe
x_axe=linspace(0,pi,501);
figure;
plot(x_axe,abs(DFTd4_half));
title('Magnitude:DFT of d4');
xlabel('W')
ylabel('Amplitude')
figure;
plot(x_axe,abs(DFTd6_half));
title('Magnitude:DFT of d6');
xlabel('W')
ylabel('Amplitude')

%A.3
%A.M:03116172/Karampinas Ioannis
%A.M:03116168/Sakos Chronis
%total tone=03116172+03116168=06232340!!!!
filename='tone sequence.wav'; %creation of file
%create the signals
myd(1,:)=d(10,:);
myd(2,:)=d(6,:);
myd(3,:)=d(2,:);
myd(4,:)=d(3,:);
myd(5,:)=d(2,:);
myd(6,:)=d(3,:);
myd(7,:)=d(4,:);
myd(8,:)=d(10,:);
vector_myd=myd(1,:);
for(i=2:8)
vector_myd=[vector_myd,zeros(1,100)];
vector_myd=[vector_myd,myd(i,:)];
end
transpose_myd=vector_myd'; %transpose array(create matrix column)
transpose_myd=transpose_myd*0.1; %divide with 10 because  Values can range between 0 and 100 with 100 being the highest quality setting.  Default is 75.
%in order to be acceptable for commands audiowrite,audioread,audioplay
audiowrite(filename,vector_myd,8192); %elements must be between -1,1
my_tone=audioread(filename);
play(audioplayer(my_tone,8192));
figure;
plot(vector_myd)
title('my_tone 06232340')
xlabel('n')
ylabel('signal')

%A.4(I)//RECT WINDOW
z=buffer (vector_myd,1100);
axe_x=linspace(0,pi,501);
a=[0;6;2;3;2;3;4;0];
for (i=1:8)
  rectwindow_fft(1:1000,i)=fft(z(1:1000,i));
  for (j=1:501)
    mirror_rectwindow_fft(j,i)=rectwindow_fft(j,i);
  end
  figure;
  plot(axe_x,abs(mirror_rectwindow_fft(:,i)));
  title([' DFT of tone  ',num2str(a(i)),'     ', ' with rectangle window method']);
 xlabel('w')
ylabel('Amplitude')
end 

%A.4(II)// HAMMING WINDOW
w=hamming(1100);
l=buffer (vector_myd,1100);
for (i=1:8)
z(:,i)=l(:,i).*w;
    hamming_window_fft(1:1000,i)=fft(z(1:1000,i)); 
    for j=1:501
        mirror_hw_fft(j,i)=hamming_window_fft(j,i);   %%pairnoume ta 500  prwta stoixeia wste na apofugoume to mirroring pou dhmiourgeitai
    end
    figure;
    plot(axe_x,abs(mirror_hw_fft(:,i)));
     title(['DFT ',num2str(a(i)),' windowed by hamming']);
    xlabel('w');
    ylabel('amplitude');
end


%A.5
pointers=zeros(2,10);
    list_of_w=zeros(2,10);
    g=d';
    fftg=fft(g);
    for  j=1:10
        for i=1:500
            hfftg(i,j)=fftg(i,j);
        end
    end
    pp=abs(hfftg);
    temp=pp;
    for i=1:10
       r=max(temp(:,i));
       pointers(1,i)=find(temp(:,i)==r);
       list_of_w(1,i)=axe_x(pointers(1,i));
       temp(pointers(1,i),i)=0;
       r=max(temp(:,i));
       pointers(2,i)=find(temp(:,i)==r);
       list_of_w(2,i)=axe_x(pointers(2,i));
    end
    k=pointers
    list_of_w

%A.6
AM_psifia=ttdecode(filename,k);
display(AM_psifia);

%A.7

load my_touchtones.mat   %dhmiourgia twn arxeiwn hxou
easyfile='easySig.wav';
    
hardfile='hardSig.wav';

    
easy=easySig';%anastrofh pinaka kai diairesh kata 10 gia na einai apodektos apo thn audiowrite
easy=easy.*.1;
figure;
  plot(easy);
     title('easySig');
    xlabel('n');
    ylabel('signal');
audiowrite(easyfile,easy,8000);
easy_res=ttdecode(easyfile,k);
display(easy_res);

hard=hardSig';%anastrofh pinaka kai diairesh kata 10 gia na einai apodektos apo thn audiowrite
hard=hard.*.1;
figure;
plot(hard);
     title('hardSig');
    xlabel('n');
    ylabel('signal');
audiowrite(hardfile,hard,8000);
hard_res=ttdecode(hardfile,k);
display(hard_res);

