function output=ttdecode(signIn, pointers)
output=[];
data=audioread(signIn);
N=length(data);
j=1;
x=linspace(0,pi,501);
for i=1:N-1
        if data(i)==0 && data(i+1)==0
             i=i+1;
        elseif data(i)==0 && data(i+1)~=0
            if data(i-1)~=0
                datan(j)=data(i);
                j=j+1;
            end
            i=i+1;
        else
            datan(j)=data(i);
            j=j+1;
            i=i+1;
        end
        
end
if data(N)~=0
    datan(j)=data(N);
end
datan=datan'.*10;
arithmos_tonwn_sto_shma=(length(datan)/1000);
w=hamming(1000);
ll=buffer(datan,1000);
for i=1:arithmos_tonwn_sto_shma
    zz(:,i)=ll(:,i).*w;
    hamming_window_fftdata(1:1000,i)=fft(zz(1:1000,i));
    for j=1:501
        half_hamming_window_fftdata(j,i)=hamming_window_fftdata(j,i);
    end
end


hdata_absfft=abs(half_hamming_window_fftdata);
temp=hdata_absfft;

    for i=1:arithmos_tonwn_sto_shma
       r=max(hdata_absfft(:,i));
       kIn(1,i)=find(hdata_absfft(:,i)==r);
       EkIn(i)=hdata_absfft(kIn(1,i),i).^2;
       if kIn(1,i)~=164
    flag=1;
    while flag==1
  
        r=max(temp(:,i));
        kIn(2,i)=find(temp(:,i)==r);
        if 0.9<x(kIn(2,i))
            flag=0;
            fr_true(2,i)=x(kIn(2,i));
        else
            temp(kIn(2,i),i)=0;
        end
    end   
   else
       flag=1;
    while flag==1
  
        r=max(temp(:,i));
        kIn(2,i)=find(temp(:,i)==r);
        if 0.9>x(kIn(2,i))
            flag=0;
            fr_true(2,i)=x(kIn(2,i));
        else
            temp(kIn(2,i),i)=0;
        end
    end   
            
    end
  end
    for i=1:8
        for j=1:10
            if kIn(1,i)==pointers(1,j)&& kIn(2,i)==pointers(2,j)
                output=[output,mod(j,10)];
            end
        end
    end
end
