%% PART 2.2 Beamforming in real signals
close all;
clear all;
%% 2.2 A.1
N=7;
c=340;
d=0.04;
u_sig=pi/4;
u_noise=3*pi/4;
fs=48000;
theta=[0:180]*pi/180;

x(:,1)=audioread('sensor_0.wav');
x(:,2)=audioread('sensor_1.wav');
x(:,3)=audioread('sensor_2.wav');
x(:,4)=audioread('sensor_3.wav');
x(:,5)=audioread('sensor_4.wav');
x(:,6)=audioread('sensor_5.wav');
x(:,7)=audioread('sensor_6.wav');
source=audioread('source.wav');

for i=1:7
    X(:,i)=fft(x(:,i));
end

w=([-length(x)/2:(length(x)-1)/2]./length(x))*2*pi;

for i=1:7
    time(i)=-(i-1-(N-1)/2)*d*cos(u_sig)/c;
end
for i=1:7
    dks(:,i)=exp(-j*w*time(i)*fs);
end
%dks=dks'; %etsi dhmiourgw kai ton ermitiano anastrofo.

yw=0;
for i=1:7
    Y(:,i)=dks(:,i).*X(:,i)/N;
    y=real(ifft(Y(:,i)));
    yw=yw+y;
end

audiowrite('real_ds.wav', yw, 48000);  % Output

%% 2.2 A.2

% Creating the time-array for x-axis
n = 1 : length(yw);
time = n / 48000;
Ts = 1/fs;

figure();
subplot(3, 1, 1);
plot(time, source);
grid;
xlabel('time (s)');
ylabel('Amplitude (dB)');
title('Clear source.wav');

subplot(3, 1, 2);
plot(time, x(:,4));
grid;
xlabel('time (s)');
ylabel('Amplitude (dB)');
title('Central noisy signal.wav');

subplot(3, 1, 3);
plot(time, yw);
grid;
xlabel('time (s)');
ylabel('Amplitude (dB)');
title('Beamforming output');

%Window
win_length= 0.005*fs;
overlap=  0.0025*fs;

figure; % Spectogram usage: [S,F,T,P] = spectrogram(x,window,noverlap,nfft,fs)
subplot(3,1,1);
[~,F,T,P] = spectrogram(source, win_length, overlap, nextpow2(length(source)), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of Clear signal from Source.wav');

subplot(3,1,3);
[~,F,T,P] = spectrogram(yw, win_length, overlap, nextpow2(length(yw)), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of y(t) output from the beamformer');

subplot(3,1,2);
[~,F,T,P] = spectrogram(x(:,4), win_length, overlap, nextpow2(length(x(:,4))), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of input signal in central microphone');
xlabel('Time (Seconds)'); 
ylabel('frequency (Hz)');

%% 2.2.A.3

%SNR tou thorivwdous shmatos sto kentriko mikrofwno (orismos)
noise_micr3 = -source + x(:,4);
snr_micr3 = mean(source.^2) / mean(noise_micr3.^2);
snr_central_micr = 10 * log10(snr_micr3);

k=x(:,4);
snoisein=k(1:14400);
sound(snoisein,48000);

figure;
plot(snoisein);
title('SSNR in central microphone');

Psnoisein= mean(snoisein.^2);
sum=0;
window=0.03*48000;    % 1440 samples
buf1=buffer(source,window);
min=0;
count=0;
for i=1:size(buf1,2)
    Px=mean(buf1(:,i).^2);
    Ps=abs(Px-Psnoisein);
    
    snr=log10(Ps/Psnoisein);
    
    if snr>min
        count=count+1;
        if snr>35
            snr=35;
        end
        sum=sum+snr;
    end
end

SSNR_in=10*sum/count;       %kentriko mikrofono

%snr output
snoiseout=yw(1:14400);
Psnoiseout= mean(snoiseout.^2);

figure;
plot(snoiseout);

sum=0;
min=0;
count=0;
buf3=buffer(yw,window);
for i=1:size(buf3,2)
    Py=mean(buf3(:,i).^2);
    Ps=abs(Py-Psnoiseout);
    snr=log10(Ps/Psnoiseout);
    if snr>min
        count=count+1;
        if snr>35
            snr=35;
        end
        sum=sum+snr;
    end
end
SSNRbeam=10*sum/count;
time;

%% 2.2 B.1
winlength = 0.03*fs;
win_overlap = winlength/3;                            %%window
win_step = winlength-win_overlap;

buf2=buffer(yw,winlength,win_overlap);
win=hamming(size(buf2,1));
snoiseout=buf2(:,4);

for i=1:size(buf2,2)
    ybuf=buf2(:,i);
    
    [Pxbuf,f] = pwelch(ybuf,[],[],winlength,'twosided');
    [Psnexit,f44] = pwelch(snoiseout,[],[],winlength,'twosided');
    
    Hw=1-(Psnexit./Pxbuf);
    
    ybuf=buf2(:,i).*win;
    fz_fft=fft(ybuf);
    filter_exit_fft=Hw.*fz_fft;
    filter_exit(:,i)=ifft(filter_exit_fft);
end

wien_out=zeros(155506,1);
for k = 1:win_step
    wien_out(k)= filter_exit(k,1);
end
for i = 2:(size(buf2,2)-1)
    for k = 1:winlength
        wien_out((i-2)*win_step + k) = filter_exit(k,i)+wien_out((i-2)*win_step + k);
    end
end

d = length(source);
for k = (win_step*(size(buf2,2)-1) + 1):d
    wien_out(k) = filter_exit(k-(win_step*(size(buf2,2)-1)),size(buf2,2));
end
sound(wien_out,48000);
figure;
plot(wien_out);
title('Wiener output');

%% 2.2 b.2
figure();
subplot(4, 1, 1);
plot(time, source);
grid;
xlabel('time (s)');
title('Clear signal from Source.wav');

subplot(4, 1, 2);
plot(time, x(:,4));
grid;
xlabel('time (s)');
title('Input signal in central microphone');
subplot(4, 1, 3);
plot(time, yw); 
grid;
xlabel('time (s)');
title('Input of the Wiener filter');

subplot(4, 1, 4);
plot(time, wien_out);
grid;
xlabel('time (s)');
title('Output of the Wiener filter');

win_length=0.005*fs;
overlap= 0.0025 * fs;

figure;     % Spectogram usage: [S,F,T,P] = spectrogram(x,window,noverlap,nfft,fs)
subplot(4,1,1);
[~,F,T,P] = spectrogram(source, win_length, overlap, nextpow2(length(source)), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of Clear signal from Source.wav');

subplot(4,1,3);
[~,F,T,P] = spectrogram(yw, win_length, overlap, nextpow2(length(yw)), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of yw(t) input of the Wiener filter');

subplot(4,1,2);
[~,F,T,P] = spectrogram(x(:,4), win_length, overlap, nextpow2(length(x(:,4))), fs);
surf(T,F,10*log10(P),'edgecolor','none'); 
axis tight; 
view(0,90);
title('Spectogram of input signal in central microphone');

subplot(4,1,4);
[S,F,T,P] = spectrogram(wien_out, win_length, overlap, nextpow2(length(wien_out)), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of wien-out(t) output of the Wiener filter');
xlabel('Time (Seconds)'); ylabel('Hz');
%%
sum=0;
min=0;
count=0;
snoiseout=wien_out(1:14400);
Psnoiseout= mean(snoiseout.^2);
window=0.1*48000;
buf4=buffer(wien_out,window);
for i=1:size(buf4,2)
    Py=mean(buf4(:,i).^2);
    Ps=abs(Py-Psnoiseout);
    snr=log10(Ps/Psnoiseout);
    if snr>min
        count=count+1;
        if snr>35
            snr=35;
        end
        sum=sum+snr;
    end
end
SSNRwiener=10*sum/count;

audiowrite('real mmse.wav', wien_out, 48000);