%DSP LAB 3
clear all;
close all;

%PART 1.4

% 1.4.1
n = [4 8 12 16];
f = 2000;
arr_u = 90;   %angle of arrival 
u = linspace(0,180);
w = 2*pi*f;
c = 340;
colour = ['g','r','b','m'];

figure;
hold on

D = 0.08;
for i=1:4
    N = n(i);
    B = (1/N)*sin((N*w)/(2*c)*D*(cosd(u)-cosd(arr_u)))./sin((1*w)/(2*c)*D*(cosd(u)-cosd(arr_u)));
    plot(u, 10*log10(abs(B)), colour(i));
    grid;
end        
        
hold off

title('Delay and sum beam pattern of Different Number of Microphones');
xlabel('angle in degrees');
ylabel('Magnitude of B in dB');

legend('n=4', 'n=8','n=12','n=16');
hold off

%1.4.2
d = [0.08 0.12 0.16 0.20];

figure;
hold on

N = 8;
for i=1:4
    D = d(i);
    B = (1/N)*sin((N*w)/(2*c)*D*(cosd(u)-cosd(arr_u)))./sin((1*w)/(2*c)*D*(cosd(u)-cosd(arr_u)));
    plot(u, 10 * log10 (abs(B)), colour(i));
    grid;
end

title('Delay and sum beam pattern of Different Microphone Distance');

xlabel('angle in degrees');
ylabel('Magnitude of B in dB');
legend('d = 4','d = 8', 'd = 16', 'd = 20');

hold off;

%1.4.3
N = 8;
D = 0.08;

u = [0 45 60];
f = linspace(0, 8000);
w=2*pi*f;
figure;
for i=1:3
    hold on
    U = u(i);
    B = (1/N)*sin((N*w)/(2*c)*D*(cosd(U)-cosd(arr_u)))./sin((1*w)/(2*c)*D*(cosd(U)-cosd(arr_u)));
    plot(f, 10 * log10 (abs(B)), colour(i));
    grid;
end    
    title(['Delay and sum beam pattern for different frequencies, angle = [0 45 60]', ]);

    xlabel('frequency in Hertz');
    ylabel('Magnitude of B in dB');
    legend('u=0','u=45','u=60');


hold off;

%1.4.4
N = 8;
D = 0.08;
f = 2000; 
w = 2*pi*f;
u = -pi: 0.001: pi;

figure; 
%suptitle('Logarithmic Polar Plots for Values of theta (0, \pi / 4, \pi / 2)')
%subplot(1, 3, 1);
arr_u = 0;                  % theta = 0

B0 = (1/N)*sin((N*w)/(2*c)*D*(cos(u)-cos(arr_u)))./sin(w/(2*c)*D*(cos(u)-cos(arr_u)));

semilogr_polar(u,abs(B0.^2), 'm');
title('Logarithmic Polar Plor for 0 rad');

figure;
%subplot(1, 3, 2)
arr_u=pi/4;                 % theta =pi/4

B1 = (1/N)*sin((N*w)/(2*c)*D*(cos(u)-cos(arr_u)))./sin(w/(2*c)*D*(cos(u)-cos(arr_u)));

semilogr_polar(u,abs(B1.^2), 'r');

title('Logarithmic Polar Plot for \pi /4 rad');

figure;
%subplot(1, 3, 3);
arr_u = pi/2;                 % theta =pi/2

B2 = (1/N)*sin((N*w/(2*c)*D*(cos(u)-cos(arr_u))))./sin(w/(2*c)*D*(cos(u)-cos(arr_u)));

semilogr_polar(u,abs(B2.^2), 'b');

title('Logarithmic Polar Plot for \pi /2 rad');

%arr_u(i) = [0 pi/4 pi/2];
%B(i)=[B0 B1 B2];

%for i=1:3
%    figure;
 %   U = arr_u(i);
 %   B = B(i) == (1/N)*sin((N*w)/(2*c)*D*(cos(u)-cos(arr_u(i))))./sin(w/(2*c)*D*(cos(u)-cos(arr_u(i))));
  %  semilogr_polar(u,abs(B.^2), 'r');

  %  title('Logarithmic Polar Plot for \pi /2 rad');
%end
