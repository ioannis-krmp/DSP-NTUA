%% PART 2.1 Beamforming in simulated signals
close all;
clear all;

%% 2.1.A.1

N=7;
d=0.08;
u_sig=pi/4;
u_noise=3*pi/4;
fs=48000;
c=340;

x(:,1)=audioread('sensor_0.wav');
x(:,2)=audioread('sensor_1.wav');
x(:,3)=audioread('sensor_2.wav');
x(:,4)=audioread('sensor_3.wav');
x(:,5)=audioread('sensor_4.wav');
x(:,6)=audioread('sensor_5.wav');
x(:,7)=audioread('sensor_6.wav');
source=audioread('source.wav');

for i=1:7
X(:,i)=fft(x(:,i));
end

w=([-length(x)/2:(length(x)-1)/2]./length(x))*2*pi;

for i=1:7
t(i)=-(i-1-(N-1)/2)*d*cos(u_sig)/c;
end
for i=1:7
dks(:,i)=exp(-(-j*w*t(i)*fs)); %thelw ton syzygh
end

y_f=0;    %teliko
for i=1:7
Y(:,i)=dks(:,i).*X(:,i)/N;
y(:,i)=ifft(Y(:,i));
y_f=y_f+real(y(:,i));
end

audiowrite('sim_ds.wav', y_f, 48000); % Output

 %% 2.1.A.2
 
 % Creating the time-array for x-axis
n = 1 : length(y_f);
time = n / 48000;

figure;
subplot(3, 1, 1);
plot(time, source);
grid;
xlabel('time (s)');
title('Clear signal from Source.wav');

subplot(3, 1, 2);
plot(time, x(:,4));
grid;
xlabel('time (s)');
title('Input signal in central microphone');

subplot(3, 1, 3);
plot(time, y_f);
grid;
xlabel('time (s)');
title('y(t): output from the beamformer');

%Window

win_length =0.005*fs;
overlap = 0.0025 * fs;

figure;     % Spectogram usage: [S,F,T,P] = spectrogram(x,window,noverlap,nfft,fs)
subplot(3,1,1);
[~,F,T,P] = spectrogram(source, win_length, overlap, nextpow2(length(source)), fs);
surf(T,F,10*log10(P),'edgecolor','none'); 
axis tight; 
view(0,90);
title('Spectogram of Clear signal from Source.wav');

subplot(3,1,2);
[~,F,T,P] = spectrogram(y_f, win_length, overlap, nextpow2(length(y_f)), fs);
surf(T,F,10*log10(P),'edgecolor','none'); 
axis tight; 
view(0,90);
title('Spectogram of y(t) output from the beamformer');

subplot(3,1,3);
[S,F,T,P] = spectrogram(x(:,4), win_length, overlap, nextpow2(length(x(:,4))), fs);
surf(T,F,10*log10(P),'edgecolor','none');
axis tight; 
view(0,90);
title('Spectogram of input signal in central microphone');
xlabel('Time (Seconds)'); 
ylabel('frequency (Hz)');

%% 2.1.A.3

%SNR tou thorivwdous shmatos sto kentriko mikrofwno
noise_micr3 = -source + x(:,4);
snr_micr3 = mean(source.^2) / mean(noise_micr3.^2);
snr_central_micr = 10 * log10(snr_micr3);

%SNR tou y output apo beamformer
noiseout = -source + y_f;
snr_out = mean(source.^2) / mean(noiseout.^2);
snr_beam = 10 * log10(snr_out);

%% 2.1.B.1

fs=48000; %sampling  frequency
z=x(:,4); 
noise=z-source;
f_noise=noise(0.47*fs:0.50*fs);
f_z=z(0.47*fs:0.5*fs);

[Pnoise,f] = pwelch(f_noise,fs*0.01,[],fs*0.03+1,fs,'twosided');
[Pz,f] = pwelch(f_z,fs*0.01,[],fs*0.03+1,fs,'twosided');

f_source=source(0.47*fs:0.5*fs);
[Psource,f] = pwelch(f_source,fs*0.01,[],fs*0.03+1,fs,'twosided');

Hw=1-(Pnoise./Pz);         %apokrisi syxnotitas wiener

figure;
plot(f,10*log10(abs(Hw)));
xlim([0,8000]);
title('Filter response IIR Wiener');
xlabel('Frequency (Hz)'); 
ylabel('Amplitude (dB)');

%% 2.1.B.2

nsd=(abs(1-Hw)).^2;

figure;
plot(f,10*log10(nsd));
xlim([0,8000]);
title('Speech distortion index');
xlabel('Frequency (Hz)'); 
ylabel('Amplitude (dB)');

%% 2.1.B.3

f_z_fft=fft(f_z);
exit_fft=Hw.*f_z_fft;
exit=ifft(exit_fft);

[Pexit,f] = pwelch(exit,fs*0.01,[],fs*0.03+1,fs,'twosided');

figure;
plot(f, 10*log10(abs(Pexit)),'g');      
hold on;
plot(f, 10*log10(abs(Pnoise)),'r');
plot(f, 10*log10(abs(Pz)),'blue');
plot(f, 10*log10(abs(Psource)),'black'); 
xlim([0,8000]);
xlabel('frequency (Hz)')
legend('exit','noise','input','clear signal');
title('Wiener output to wiener input');
hold off;

%% 2.1.B.4
noise1=exit-f_source;
snr_exit=mean(f_source.^2)/mean(noise1.^2);
snr_exit_db=10*log10(snr_exit);
snr_in=mean(f_source.^2)/mean(f_noise.^2);
snr_in_db=10*log10(snr_in);

fy=y_f(0.47*fs:0.50*fs);
[Py,f] = pwelch(fy,fs*0.01,[],fs*0.03+1,fs,'twosided');

figure;
plot(f, 10*log10(abs(Pexit)),'g'); 

hold on;
plot(f, 10*log10(abs(Py)),'r');
plot(f, 10*log10(abs(Pz)),'blue');
plot(f, 10*log10(abs(Psource)),'black'); 
xlim([0,8000]);
xlabel('frequency(Hz)');
ylabel('Amplitude (dB)');
legend('Wiener exit','Beamforming exit','input','clear signal');
title('Wiener output to Beamforming input');
hold off;
