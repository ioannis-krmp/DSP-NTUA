function y = quantizingst(v)
Bk=8;
levels=2^Bk;

range=1-(-1);
    
step=range/levels;


%finding layers

 layer(1)=-1;
    for i=2:levels
    layer(i)=layer(i-1)+step;
    end





for j=1:size(v,2)
        dif=abs(layer-v(j));
        min_dif=min(dif);
        thesi=find(dif==min_dif);
        y(j)=layer(thesi);
end
end