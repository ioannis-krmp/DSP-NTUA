function noisePowerDensitySpectrum = findNoiseMaskers(powerDensitySpectrum,tonePowerDensitySpectrum,b)
% Pnm = findNoiseMaskers(P,Ptm,b) finds the positions and spectrum values 
% of the noise maskers.
%
%
% Inputs:
% P: Power density spectrum. It is an array with length either N or N/2, as
% you can pass either the full-length spectrum or its first half. N is the 
% length of the FFT (N=512).
%
% Ptm: Power density spectrum of the tone maskers. It is an array with 
% length N/2, where N is the length of the FFT (N=512). It has the spectrum
% values at positions with a tone masker and zeros everywhere else.
%
% b: It is an array with length N/2 that has the frequency values in Barks 
% scale.
%
%
% Output:
% Pnm: Power density spectrum of the noise maskers. It is an array with 
% size 1xN/2, where N is the length of the FFT (N=512). It has the spectrum
% values at positions with a noise masker and zeros everywhere else.
%
%
% Digital Signal Processing 2011-2012, CVSP Group, ECE, NTUA.
%
%

if nargin<3
    error('findNoiseMaskers: The function should take 3 inputs. See help findNoiseMaskers for more details.');
end;
if isvector(powerDensitySpectrum)==0 || (length(powerDensitySpectrum)~=512 && length(powerDensitySpectrum)~=256)
    error('findNoiseMaskers: Input P should be a vector with length 256 or 512. See help findNoiseMaskers for more details.');
end;
if isvector(tonePowerDensitySpectrum)==0 || length(tonePowerDensitySpectrum)~=256
    error('findNoiseMaskers: Input Ptm should be a vector with length 256. See help findNoiseMaskers for more details.');
end;
if isvector(b)==0 || length(b)~=256
    error('findNoiseMaskers: Input b should be a vector with length 256. See help findNoiseMaskers for more details.');
end;

%% INITIALIZATION
noisePowerDensitySpectrum = zeros(1,length(tonePowerDensitySpectrum));
lowBoundary = 1;
highBoundary = find(b<1,1,'last');

for band=1:25
    % Initialize noise members
    noiseMembers = ones(1,highBoundary-lowBoundary+1);
    
    % go through tonal power spectrum
    for k=lowBoundary:highBoundary
        % if there is a tone
        if tonePowerDensitySpectrum(k)>0
            % check frequency location and determine neighborhood length
            if (k>2 && k<63)
                m=2;
            elseif (k>=63 && k<127)
                m=3;
            elseif (k>=127 && k<=250)
                m=6;
            else
                m=0;
            end
            % set all members of the neighborhood to 0, which
            % removes them from the list of noise members
            for n = (k-lowBoundary+1)-m : (k-lowBoundary+1)+m,
                if (n > 0)
                    noiseMembers(n) = 0;
                end
            end
        end
    end
    
    % those indices in noise_members that have a 1
    % are part of the noise masker.
    
    % go through the noise locations and perform power summation,
    % which requires going back to magnitude (dB doesn't add linearly.).
    
    % if there are no noise members in the range, then get out
    if (isempty(find(noiseMembers)))
        Pnm_at_loc=0;
        loc=-1;
    else
        temp=0;
        for k=(lowBoundary+find(noiseMembers)-1),
            temp = temp + dbinv(powerDensitySpectrum(k));
        end
        
        % take summation and make it into dB
        Pnm_at_loc=10*log10(temp);
        
        loc=geomean(lowBoundary+find(noiseMembers)-1);
    end
    
    if (loc ~= -1)
        noisePowerDensitySpectrum(floor(loc)) = Pnm_at_loc;
    end
    
    lowBoundary = highBoundary;
    highBoundary = find(b<band+1,1,'last');
end;

end

function mag = dbinv (sigdb)
% magnitude = dbinv(power_in_decibels)
%
% loginv converts power in decibels to power in magnitude.

mag = 10.^(0.1.*sigdb);

end