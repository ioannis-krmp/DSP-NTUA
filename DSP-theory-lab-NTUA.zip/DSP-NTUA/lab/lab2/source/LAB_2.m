%2nd LAB
clear all;
close all;


%VHMA 1.0
[x,fs]=audioread('music-dsp19.wav');
xL=x(:,1);
xR=x(:,2);
x=(xL+xR)./2; %pairnw kai to aristero kanali kai to deksio kanali
xlen=length(x);
N=512;  %deigmata parathuropoihshs
Nh=N/2;
x_max=max(x); %megisto shmatos
normalized_x=x/abs(x_max); %kanonikopoihsh
%figure 1 %plot normalized
figure,plot(normalized_x);
title('normalized signal');
ylabel('amplitude');
xlabel('n');
normalized_x=normalized_x';

%VHMA 1.1   
xbuff = buffer(normalized_x, N);      
[rown, coln] = size(xbuff);
w=hanning(N); %hanning window
signal=xbuff.*w;
%sig_han=fft(signal,N);
%plot(sig_han);
sig_han=[];
f= (1: Nh) * (fs / N); 
P=[];
M = 32; 
L = 2*M; 
b=13*atan(.00076*f)+3.5*atan((f/7500).^2);
Tq=3.64*(f/1000).^(-0.8)-6.5*exp((-0.6)*((f/1000)-3.3).^2)+(10.^(-3))*(f/1000).^4;
PN=90.302;                       %constant in dB
%P=PN +10*log((abs(sig_han)).^2); %0<=k<=N/2 //n=512

for i= 1:coln
 sm_han(:,i)=w.*xbuff(:,i);
    K(:,i)=PN+10*log10((abs(fft(sm_han(:,i)).^2)));
    sig_han=[sig_han, sm_han(:,i)'];
    P(:,i)=K(1:256,i);
end
%figure 2
%plotting 100st window

figure;
subplot(2,1,1);
plot(sm_han(:,100));
title('windowed signal (100st window)');
ylabel('amplitude');
xlabel('n');

%figure 3
%plotting spectrum of 100st window (not mirrored)
%figure;
subplot(2,1,2);
plot(P(:,100));
title('Spectrum of windowed signal (100st window)');
ylabel('amplitude');
xlabel('n');

%1.2
b=13*atan(.00076*f)+3.5*atan((f/7500).^2);

St=zeros(256,1179);
dk=[0 0 0 0 0];
PTM=zeros(256,1179);
%Computing matrix St
for i=1:1179
    %Computing matrix Detla
    for k=3:250
      
        if k<63
        dk=[2 0 0 0 0];
        flag=1;
        end
    if k<127 && k>62
    dk=[2 3 0 0 0];
    flag=2;
    end
    if k>126
        dk=[2 3 4 5 6];
        flag=5;
    end
        if P(k,i)>P(k+1)&& P(k,i)>P(k-1)
            ct=0;
            for j=1:5
            if P(k,i)>(P(k+dk(j),i)+7)&& P(k,i)>(P(k-dk(j),i)+7)
                ct=ct+1;
            end
            end
            if ct==flag
                St(k,i)=1;
            end
        end
        if St(k,i)==1
            PTM(k,i)=10*log10(10^(.1*(P(k-1,i)))+10^(.1*(P(k,i)))+10^(.1*(P(k+1,i))));
            
        end
    end
   
end
%end_of_for
%figure 4
%plotting tone maskers for 100st window
figure;
subplot(2,1,1);
hold on;
plot(f,PTM(:,100),'b');
plot(f,P(:,100),'g');
plot(f,Tq,'r');
title('Power Spectrum of  tone maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Hz)');
hold off;
subplot(2,1,2);
hold on;
plot(b,PTM(:,100),'b');
plot(b,P(:,100),'g');
plot(b,Tq,'r');
title('Power Spectrum of  tone maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Bark)');
%finding noise maskers
for i=1:1179
    [Pnm]=findNoiseMaskers(P(:,i),PTM(:,i),b);
    PNM(i,:)=Pnm;
end

%% plotting noise maskers for 100st window
figure;
subplot(2,1,1);
hold on;
plot(f,PNM(100,:));
plot(f,P(:,100),'g');
plot(f,Tq,'r');
title('Power Spectrum of noise maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Hz)');
hold off;
subplot(2,1,2);
hold on;
plot(b,PNM(100,:));
plot(b,P(:,100),'g');
plot(b,Tq,'r');
title('Power Spectrum of noise maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Bark)');
hold off;


%//////////////////////////////////////////////////
%% 1.3
PTM=PTM';
for i=1:1179
    [PTM1(i,:),PNM1(i,:)]=checkMaskers(PTM(i,:),PNM(i,:),Tq,b);
end
PTM=PTM';
PNM=PNM';
PTM1=PTM1';
PNM1=PNM1';

%% plotting declined maskers

figure;
subplot(2,1,1);
hold on;
plot(f,PTM1(:,100),'b');
plot(f,P(:,100),'g');
plot(f,Tq,'r');
title('Power Spectrum of declined noise maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Hz)');
hold off;
subplot(2,1,2);
hold on;
plot(b,PTM1(:,100),'b');
plot(b,P(:,100),'g');
plot(b,Tq,'r');
title('Power Spectrum of declined noise maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Bark)');
hold off;
%////////////////////////

figure;
subplot(2,1,1);
hold on;
plot(f,PNM1(:,100),'b');
plot(f,P(:,100),'g');
plot(f,Tq,'r');
title('Power Spectrum of declined noise maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Hz)');
hold off;
subplot(2,1,2);
hold on;
plot(b,PNM1(:,100),'b');
plot(b,P(:,100),'g');
plot(b,Tq,'r');
title('Power Spectrum of declined noise maskers (100st window)');
ylabel('amplitude');
xlabel('frequency(Bark)');
hold off;
%/////////////////////////////////
%% 1.4

SFN=zeros(256,256);
SFT=zeros(256,256);
Tnm=zeros(256,256);
Ttm=zeros(256,256);
DB1=1;


message='Write 1 for adaptive quantizer and anything else for nonadaptive';
input_user = input(message);
for t=1:1179
     for j=1:256
        if PTM1(j,t)>0
            for i=1:256
                if b(i)>b(j)-3 && b(i)<b(j)+8
                    DB1=b(i)-b(j);
                if DB1>=-3 && DB1<-1
                    SFT(i,j)=17*DB1-0.4*PTM1(j,t)+11;
                end
                if DB1>=-1 && DB1<0
                    SFT(i,j)=(.4*PTM1(j,t)+6)*DB1;
                end
                if DB1>=0 && DB1<1
                    SFT(i,j)=-17*DB1;                
                end
                if DB1>=1 && DB1<8
                    SFT(i,j)=DB1*(.15*PTM1(j,t)-17)-.15*PTM1(j,t);
                end
                Ttm(i,j)=PTM(j,t)-.275*b(j)+SFT(i,j)-6.025;
                end
            end
        end
               if PNM1(j,t)>0
                for i=1:256
                if b(i)>b(j)-3 && b(i)<b(j)+8
                    DB1=b(i)-b(j);
                if DB1>=-3 && DB1<-1
                    SFN(i,j)=17*DB1-0.4*PNM1(j,t)+11;
                end
                if DB1>=-1 && DB1<0
                    SFN(i,j)=(.4*PNM1(j,t)+6)*DB1;
                end
                if DB1>=0 && DB1<1
                    SFN(i,j)=-17*DB1;                
                end
                if DB1>=1 && DB1<8
                        SFN(i,j)=DB1*(.15*PNM1(j,t)-17)-.15*PNM1(j,t);
                end
                Tnm(i,j)=PNM(j,t)-.175*b(j)+SFN(i,j)-2.025;   
                end
                end
               end 
               end
             
    
    %% 1.5
    sum1=zeros(1,256);
    sum2=zeros(1,256);
    for i=1:256
        for j=1:256
            sum1(i)=sum1(i)+10^(0.1*Ttm(i,j));
            sum2(i)=sum2(i)+10^(0.1*Tnm(i,j));
        end
        Tg(i)=10*log10(10^(Tq(i)*0.1)+sum1(i)+sum2(i));
    end
%%%%%%%%%%%%%%

%%%%SECOND PART
for n=1:L
        for k=1:M
            h(k,n)=sin(((n-1)+1/2)*pi/(2*M))*sqrt(2/M)*cos((2*(n-1)+M+1)*(2*(k-1)+1)*pi/(4*M)); 
        end
     end
     
       for n=1:L
        for k=1:M
          g(k,n)=h(k,2*M-(n-1)); 
        end
     end
    if t==1
      
        figure;
        subplot(3,1,1);
        plot(b,Tg,'k');
        subplot(3,1,2);
        plot(b,P(:,100),'g');
        subplot(3,1,3);
        plot(b,Tq,'r');
       
        figure;
        hold on;
        plot(b,Tg,'k');
        plot(b,P(:,100),'g');
        plot(b,Tq,'r');
        hold off;
        
        figure;
        subplot(2,1,1);
        plot(h(10,:));
        title('Filtrer h=10 impulse response');
        ylabel('amplitude');
        xlabel('n');
        
        subplot(2,1,2);
        plot(g(10,:));
        title('Filtrer g=10 impulse response');
        ylabel('amplitude');
        xlabel('n');
    end
     %% 2.1
    
     for k=1:32
         u(k,:)=conv(xbuff(:,t),h(k,:));
    
     end
      for k=1:32
         y(k,:)=downsample(u(k,:),M); 
     end
      %% 2.2
    
      data=xbuff(:,t);
      R = 2^16;
    for k=1:32
        Fk(k)= (2*k-1)*fs /(4*M); 
        low(k)=Fk(k)-fs/(4*M)-1;
        high(k)=Fk(k)+fs/(4*M)-1;
    end
    
    for k=1:32
    
        for i=1:256
            if f(i)>low(k) && f(i)<high(k)
                TT(i,k)=Tg(i);
            end
        end
        maxx=max(TT(:,k));
        for i=1:size(TT,1)
            if TT(i,k)==0
               TT(i,k)=maxx;
            end
        end
    minTg(k)=min(TT(:,k));
    end
    
    
    for k=1:32
        if (input_user==1)
            Bk(k)=ceil(log2((R/minTg(k)))-1);
            if Bk(k)>16
                Bk(k)=16;
            end
        else
            Bk(k)=8;
        end
    end
    for k=1:32
        v=y(k,:);
        y_b=quantizing(Bk(k),v);
        y_bar(k,:)=y_b;
    end
    
    %% 2.3
    W=zeros(32,size(y_bar,2));
    
    for k=1:32
    for n=1:size(y_bar,2)*M
        if mod(n,M)==0
            W(k,n)=y_bar(k,n/M);
        else
            W(k,n)=0;
        end
    end
        x_ba(k,:)=conv(W(k,:),g(k,:));
    
    end
    x_bar(t,:)=zeros(1,size(x_ba,2));
    for k=1:32
       x_bar(t,:)=x_bar(t,:)+x_ba(k,:);
    end
    x_ba=zeros(32,639);
    output(t,:)=x_bar(t,:);
end
%% plotting Ttm and Tnm
figure;
subplot(2,2,1);
s=surf(Ttm,'FaceAlpha',0.5,'edgecolor','none');
title(' 3D tone maskers threshhold');
subplot(2,2,3);
s=surf(Ttm,'FaceAlpha',0.5,'edgecolor','none');
title('tone maskers threshhold');
view(0,90);

subplot(2,2,2);
s=surf(Tnm,'FaceAlpha',0.5,'edgecolor','none');
title(' 3D noise maskers threshhold');
subplot(2,2,4);
s=surf(Tnm,'FaceAlpha',0.5,'edgecolor','none');
title('noise maskers threshhold');
view(0,90);
%% plotting Global Masking Threshold
figure;
subplot(2,1,1);
plot(b,Tq,'b');
title('Absolute Threshold of Hearing');
subplot(2,1,2);
plot(b,Tg,'r');
title('Global Masking Threshold');
figure;
hold on;
plot(b,Tq,'+');
plot(b,Tg,'--');
xlabel('Bark scale');
ylabel('Amplitude');
legend('Absolute Threshold of Hearing', 'Global Masking Threshold');
hold off;

%%
figure;
subplot(2,1,1);
hold on;
plot(output(1,:));
plot(xbuff(:,1));
title('first window');
hold off;
subplot(2,1,2);
hold on;
plot(output(100,:));
plot(xbuff(:,100));
title('100st window');
hold off;


N=512;
WinNum=size(output,1);
XX=output;
final=zeros(1,650415);
%%   % Overlap-Adding the windowed signals which were created for each method.
    final(1 : N+L-1) = XX(1, L+1 : end);
    for window = 2 : WinNum - 1
        for l = 1 : N + 2*L - 1
            final((window-1)*N + l - L) = final((window-1)*N + l - L) + XX(window, l);
        end
    end
    sound(final,44100);
    
    Bkmean=mean(Bk);
Comp_perc=(Bkmean/16)*100

Error=(final-normalized_x);

if input_user==1
    audiowrite('adaptive.wav', final, fs);
    figure;
    subplot(2,1,1);
    plot(final);
    title('Final signal via 1st method (adaptive quantizer)');
    xlabel('n');
    ylabel('amplitude');
    
    subplot(2,1,2);
    plot(Error);
    title('Error via 1st method (adaptive quantizer)');
    xlabel('n');
    ylabel('amplitude');
    MSError=mean(Error.^2)

else
    audiowrite('nonadaptive.wav', final, fs);
    figure;
    subplot(2,1,1);
    plot(final);
    title('Final signal via 2nd method (non-adaptive quantizer)');
    xlabel('n');
    ylabel('amplitude');
    
    subplot(2,1,2);
    plot(Error);
    title('Error via 2nd method (non-adaptive quantizer)');
    xlabel('n');
    ylabel('amplitude');
    MSError=mean(Error.^2)
end
%end
