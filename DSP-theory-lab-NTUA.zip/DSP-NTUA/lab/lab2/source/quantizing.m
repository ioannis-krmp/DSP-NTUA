function y = quantizing(Bk, v)
levels=2^Bk;

range=abs(max(v)-min(v));
    
step=range/levels;


%finding layers

 layer(1)=min(v);
    for i=2:levels
    layer(i)=layer(i-1)+step;
    end





for j=1:size(v,2)
        dif=abs(layer-v(j));
        min_dif=min(dif);
        thesi=find(dif==min_dif);
        y(j)=layer(thesi);
end
end