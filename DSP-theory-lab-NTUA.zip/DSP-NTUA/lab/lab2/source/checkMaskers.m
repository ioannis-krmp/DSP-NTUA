function [tonePowerDensitySpectrum_aboveATH,noisePowerDensitySpectrum_aboveATH] = checkMaskers(tonePowerDensitySpectrum,noisePowerDensitySpectrum,ATH,b)
% [Ptm_out,Pnm_out] = checkMaskers(Ptm,Pnm,ATH,b) decimates and reorganizes
% the tone and noise maskers using 2 criteria. 
% 1) Any tone or noise maskers below the Absolute Threshold of Hearing are
% discarded.
% 2) Any pair of maskers with distance less than 0.5 Bark is replaced by
% the stronger of the two, thus the one with greater spectrum.
%
%
% Inputs:
% Ptm: Power density spectrum of the tone maskers. It is an array with 
% size 1xN/2, where N is the length of the FFT (N=512). It has the spectrum
% values at positions with a tone masker and zeros everywhere else.
%
% Pnm: Power density spectrum of the noise maskers. It is an array with 
% size 1xN/2, where N is the length of the FFT (N=512). It has the spectrum
% values at positions with a noise masker and zeros everywhere else.
%
% ATH: Absolute Threshold of Hearing. It is an array with size 1xN/2.
%
% b: It is an array with size 1xN/2 that has the frequency values in Barks 
% scale.
%
%
% Outputs:
% Ptm_out, Pnm_out: Power density spectrum of the tone and noise maskers 
% respectively. They are two arrays with size 1xN/2, where N is the length 
% of the FFT (N=512). They are the decimated and reorganized power density 
% spectrum arrays of the tone and noise maskers.
%
%
% Digital Signal Processing 2011-2012, CVSP Group, ECE, NTUA.
%
%

if nargin<4
    error('checkMaskers: The function should take 4 inputs. See help checkMaskers for more details.');
end;
if isvector(tonePowerDensitySpectrum)==0 || size(tonePowerDensitySpectrum,2)~=256 || size(tonePowerDensitySpectrum,1)~=1
    error('checkMaskers: Input Ptm should be a vector with size 1x256. See help checkMaskers for more details.');
end;
if isvector(noisePowerDensitySpectrum)==0 || size(noisePowerDensitySpectrum,2)~=256 || size(noisePowerDensitySpectrum,1)~=1
    error('checkMaskers: Input Pnm should be a vector with size 1x256. See help checkMaskers for more details.');
end;
if isvector(ATH)==0 || size(ATH,2)~=256 || size(ATH,1)~=1
    error('checkMaskers: Input ATH should be a vector with size 1x256. See help checkMaskers for more details.');
end;
if isvector(b)==0 || size(b,2)~=256 || size(b,1)~=1
    error('checkMaskers: Input b should be a vector with size 1x256. See help checkMaskers for more details.');
end;

%% 1st CRITERION: Keep maskers above absolute threshold
tonePowerDensitySpectrum_aboveATH = tonePowerDensitySpectrum.*(tonePowerDensitySpectrum>ATH);
noisePowerDensitySpectrum_aboveATH = noisePowerDensitySpectrum.*(noisePowerDensitySpectrum>ATH);

%% 2nd CRITERION: Replace any pair of maskers within a 0.5 bark distance
% create matrix existingMaskers: 
% 1st col -> 1 if tone 2 if noise
% 2nd col -> index in tonePowerDensitySpectrum_aboveATH or noisePowerDensitySpectrum_aboveATH
% 3rd col -> value in tonePowerDensitySpectrum_aboveATH or noisePowerDensitySpectrum_aboveATH
existingToneMaskersIndices = find(tonePowerDensitySpectrum_aboveATH)';
existingToneMaskersValues = tonePowerDensitySpectrum_aboveATH(existingToneMaskersIndices)';
numberOfToneMaskers = length(existingToneMaskersValues);
existingNoiseMaskersIndices = find(noisePowerDensitySpectrum_aboveATH)';
existingNoiseMaskersValues = noisePowerDensitySpectrum_aboveATH(existingNoiseMaskersIndices)';
numberOfNoiseMaskers = length(existingNoiseMaskersValues);
existingMaskers = [ones(numberOfToneMaskers,1) existingToneMaskersIndices existingToneMaskersValues; ...
    2*ones(numberOfNoiseMaskers,1) existingNoiseMaskersIndices existingNoiseMaskersValues];
totalNumberOfMaskers = size(existingMaskers,1);


for m=1:totalNumberOfMaskers
    % determine low and high thresholds of critical bandwidth
    maskerLocationBarks = b(existingMaskers(m,2));
    criticalBandwidthLow  = maskerLocationBarks-0.5;
    criticalBandwidthHigh = maskerLocationBarks+0.5;
    % determine what indices these values correspond to
    indexLow  = find(b<criticalBandwidthLow,1,'last');
    if (isempty(indexLow)); indexLow = 1; else indexLow = indexLow+1; end
    indexHigh = find(b<criticalBandwidthHigh,1,'last');
    % find maskers in bandwidth
    conflictingMaskers = find(existingMaskers(:,2)>=indexLow & existingMaskers(:,2)<=indexHigh);
    % keep max
    if length(conflictingMaskers)>1
        sortedMaskers = sortrows(existingMaskers(conflictingMaskers,:),3);
        for j=1:size(sortedMaskers,1)-1
            if sortedMaskers(j,1)==1
                tonePowerDensitySpectrum_aboveATH(sortedMaskers(j,2)) = 0;
            elseif sortedMaskers(j,1)==2
                noisePowerDensitySpectrum_aboveATH(sortedMaskers(j,2)) = 0;
            end;
        end;
    end;
end;

end