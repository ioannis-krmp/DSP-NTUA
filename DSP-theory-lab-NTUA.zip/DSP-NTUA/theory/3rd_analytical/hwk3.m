clear all;
close all;

N = 1024;
n = 1:N;

w_1=0.3*pi;         % Angular Frequencies
w_2=0.6*pi;
w_3=0.7*pi;

f1 = rand*2*pi;     %Phases
f2 = rand*2*pi;
f3 = rand*2*pi;

u = randn(1, N);    % white noise

x = 3*sin(w_1*pi*n + f1) +5*cos(w_2*pi*n + f2) +2*sin(w_3*pi*n +f3) + u;

figure;
plot(x);
title('Signal');
xlabel('Samples');
ylabel('Amplitude');

[per,f]=periodogram(x);
figure;
plot(f,per);
title('Periodogram');
xlabel('Normalised frequency');
ylabel('power spectrum');

w = hamming(N/4);
[pw,f]=pwelch(x,w);
figure;
plot(f,pw);
title('Welch Method');
xlabel('Normalised frequency');
ylabel('power spectrum');

var_per=var(per)
var_pw=var(pw)